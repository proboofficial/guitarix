#ifdef __APPLE__

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>
#import <cairo.h>
#import <cairo-quartz.h>

extern "C" {

#include "xwidget.h"
#include "xwidget_private.h"
void _motion_notify(Widget_t *w, XMotionEvent *xmotion, void *user_data) {
    if (w && w->func.motion_callback) {
        w->func.motion_callback(w, xmotion, user_data);
    }
}


@interface XWidgetView : NSView {
@public
    Widget_t *widget;
    double lastDragValue;
}
@end

@implementation XWidgetView

- (BOOL)isFlipped { return YES; }

- (instancetype)initWithWidget:(Widget_t *)w frame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        widget = w;
        lastDragValue = 0.0;
        [self setWantsLayer:YES];
        NSTrackingArea *tracking = [[NSTrackingArea alloc] initWithRect:self.bounds
                                                                options:(NSTrackingMouseEnteredAndExited |
                                                                         NSTrackingMouseMoved |
                                                                         NSTrackingActiveAlways |
                                                                         NSTrackingInVisibleRect)
                                                                  owner:self
                                                               userInfo:nil];
        [self addTrackingArea:tracking];
    }
    return self;
}


- (void)drawRect:(NSRect)dirtyRect {
    if (!widget) return;
    transparent_draw(widget, NULL);

    CGContextRef cgContext = [[NSGraphicsContext currentContext] CGContext];
    NSRect bounds = [self bounds];
    cairo_surface_t *surface = cairo_quartz_surface_create_for_cg_context(
        cgContext, bounds.size.width, bounds.size.height);
    cairo_t *cr = cairo_create(surface);
    cairo_set_source_surface(cr, widget->surface, 0, 0);
    cairo_paint(cr);
    cairo_destroy(cr);
    cairo_surface_destroy(surface);
}

- (BOOL)acceptsFirstResponder {
    return YES;
}

- (void)mouseDown:(NSEvent *)event {
    if (!widget) return;
    NSPoint loc = [self convertPoint:[event locationInWindow] fromView:nil];

    // only activate the knob, do not change its value
    XButtonEvent xbutton = {0};
    xbutton.x = loc.x;
    xbutton.y = loc.y;
    xbutton.button = Button1;

    if (widget->flags & HAS_TOOLTIP) hide_tooltip(widget);
    _button_press(widget, &xbutton, NULL);

    // remember the starting position
    adj_set_motion_state(widget, xbutton.x, xbutton.y);
}


- (void)mouseUp:(NSEvent *)event {
    if (!widget) return;
    NSPoint loc = [self convertPoint:[event locationInWindow] fromView:nil];

    XButtonEvent xbutton = {0};
    xbutton.x = loc.x;
    xbutton.y = loc.y;
    xbutton.button = Button1;

    _check_grab(widget, &xbutton, widget->app);
    _has_pointer(widget, &xbutton);
    widget->state = (widget->flags & HAS_POINTER) ? 1 : 0;
    _check_enum(widget, &xbutton);

    if (widget->func.button_release_callback)
        widget->func.button_release_callback(widget, &xbutton, NULL);

    // force redraw of the value and color
    transparent_draw(widget, NULL);
    [self setNeedsDisplay:YES];
}


- (void)mouseDragged:(NSEvent *)event {
    if (!widget) return;
    NSPoint loc = [self convertPoint:[event locationInWindow] fromView:nil];

    XMotionEvent xmotion = {0};
    xmotion.x = loc.x;
    xmotion.y = loc.y;

    // change value only while dragging
    adj_set_motion_state(widget, xmotion.x, xmotion.y);
    _motion_notify(widget, &xmotion, NULL);
    if (widget->func.motion_callback)
        widget->func.motion_callback(widget, &xmotion, NULL);

    [self setNeedsDisplay:YES];
}

- (void)mouseMoved:(NSEvent *)event {
    if (!widget) return;
    NSPoint loc = [self convertPoint:[event locationInWindow] fromView:nil];

    XMotionEvent xmotion = {0};
    xmotion.x = loc.x;
    xmotion.y = loc.y;

    // moving the mouse alone does not change the value
    if (widget->func.motion_callback)
        widget->func.motion_callback(widget, &xmotion, NULL);
}

- (void)mouseEntered:(NSEvent *)event {
    if (!widget) return;

    // react only if this is not the main window
    if (widget->flags & IS_WINDOW) return;

    widget->state = 1;
    transparent_draw(widget, NULL);
    [self setNeedsDisplay:YES];
}

- (void)mouseExited:(NSEvent *)event {
    if (!widget) return;

    // react only if this is not the main window
    if (widget->flags & IS_WINDOW) return;

    widget->state = 0;
    transparent_draw(widget, NULL);
    [self setNeedsDisplay:YES];
}


- (void)keyUp:(NSEvent *)event {
    if (!widget) return;
    XKeyEvent xkey = {0};
    xkey.keycode = [event keyCode];
    if (widget->func.key_release_callback)
        widget->func.key_release_callback(widget, &xkey, NULL);
}




@end

static void ensure_nsapp_initialized() {
    if (NSApp == nil) {
        [NSApplication sharedApplication];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        [NSApp finishLaunching];
    }
}

Display* os_open_display(char* display_name) { return nullptr; }
void os_close_display(Display* dpy) {}

Window os_get_root_window(Widget_t* w) { return nil; }

void os_destroy_window(Widget_t* w) {
    if (!w || !w->widget) return;

    id obj = (__bridge id)w->widget;
    if ([obj isKindOfClass:[NSWindow class]]) {
        [(NSWindow*)obj close];
    } else if ([obj isKindOfClass:[NSView class]]) {
        [(NSView*)obj removeFromSuperview];
    }

    // notify the host that the GUI is closed (like on Linux)
    if (w->func.mem_free_callback) {
        w->func.mem_free_callback(w, NULL);
    }

    // set the state to "destroyed"
    w->state = 4;
}

void os_translate_coords(Widget_t* w, Window from_window, Window to_window,
                         int from_x, int from_y, int* to_x, int* to_y) {
    id fromObj = (__bridge id)from_window;
    NSWindow *fromWin = nil;

    if ([fromObj isKindOfClass:[NSView class]]) {
        fromWin = [(NSView*)fromObj window];
    } else if ([fromObj isKindOfClass:[NSWindow class]]) {
        fromWin = (NSWindow*)fromObj;
    }

    // Convert point from local to screen coordinates
    NSPoint pt = NSMakePoint(from_x, from_y);
    if (fromWin) {
        pt = [fromWin convertRectToScreen:NSMakeRect(pt.x, pt.y, 0, 0)].origin;
    }

    *to_x = pt.x;
    *to_y = pt.y;
}


void os_get_window_metrics(Widget_t* w_, Metrics_t* metrics) {
    if (!w_ || !w_->widget) return;
    id obj = (__bridge id)w_->widget;

    if ([obj isKindOfClass:[NSWindow class]]) {
        NSWindow *window = (NSWindow *)obj;
        NSRect frame = [window frame];
        metrics->x = frame.origin.x;
        metrics->y = frame.origin.y;
        metrics->width = frame.size.width;
        metrics->height = frame.size.height;
        metrics->visible = [window isVisible];
    } else if ([obj isKindOfClass:[NSView class]]) {
        NSView *view = (NSView *)obj;
        NSRect frame = [view frame];
        metrics->x = frame.origin.x;
        metrics->y = frame.origin.y;
        metrics->width = frame.size.width;
        metrics->height = frame.size.height;
        metrics->visible = ![view isHidden];
    }
}

void os_set_window_min_size(Widget_t* w, int min_width, int min_height,
                            int base_width, int base_height) {
    if (!w || !w->widget) return;
    id obj = (__bridge id)w->widget;
    if ([obj isKindOfClass:[NSWindow class]]) {
        // Set minimum content size for NSWindow
        [(NSWindow*)obj setContentMinSize:NSMakeSize(min_width, min_height)];
    }
}

void os_move_window(Display* dpy, Widget_t* w, int x, int y) {
    if (!w || !w->widget) return;
    id obj = (__bridge id)w->widget;

    if ([obj isKindOfClass:[NSWindow class]]) {
        NSWindow *window = (NSWindow *)obj;
        NSRect frame = [window frame];

        // Use coordinates directly without converting Y
        frame.origin.x = x;
        frame.origin.y = y;

        [window setFrame:frame display:YES];
    } else if ([obj isKindOfClass:[NSView class]]) {
        NSView *view = (NSView *)obj;
        NSRect frame = [view frame];
        frame.origin.x = x;
        frame.origin.y = y;
        [view setFrame:frame];
    }
}


void os_resize_window(Display* dpy, Widget_t* w, int width, int height) {
    if (!w || !w->widget) return;
    id obj = (__bridge id)w->widget;

    if ([obj isKindOfClass:[NSWindow class]]) {
        NSWindow *window = (NSWindow *)obj;

        // Set content size so client area matches requested size, just like on Windows
        [window setContentSize:NSMakeSize(width, height)];
    } else if ([obj isKindOfClass:[NSView class]]) {
        [(NSView *)obj setFrameSize:NSMakeSize(width, height)];
    }
}


void os_get_surface_size(cairo_surface_t* surface, int* width, int* height) {
    if (!surface) return;
    *width = cairo_image_surface_get_width(surface);
    *height = cairo_image_surface_get_height(surface);
}

void os_set_widget_surface_size(Widget_t* w, int width, int height) {
    if (!w) return;
    if (w->cr) cairo_destroy(w->cr);
    if (w->surface) cairo_surface_destroy(w->surface);
    w->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
    w->cr = cairo_create(w->surface);
}

void os_create_main_window_and_surface(Widget_t* w, Xputty* app, Window win,
                                       int x, int y, int width, int height) {
    ensure_nsapp_initialized();
    childlist_add_child(app->childlist, w);

    NSLog(@"[CREATE] win=%p x=%d y=%d w=%d h=%d", (void*)win, x, y, width, height);

    if (win == (Window)-1) {
        // Main application window
        NSRect rect;
        if (x == 0 && y == 0) {
            rect = NSMakeRect(0, 0, width, height);
            NSLog(@"[CREATE] Main window: using default position, will center");
        } else {
            rect = NSMakeRect(x, y, width, height);
            NSLog(@"[CREATE] Main window: using provided position x=%d y=%d", x, y);
        }

        NSWindow *window = [[NSWindow alloc] initWithContentRect:rect
                                                       styleMask:(NSWindowStyleMaskTitled |
                                                                  NSWindowStyleMaskClosable |
                                                                  NSWindowStyleMaskResizable)
                                                         backing:NSBackingStoreBuffered
                                                           defer:NO];
        XWidgetView *view = [[XWidgetView alloc] initWithWidget:w frame:NSMakeRect(0, 0, width, height)];
        [window setContentView:view];
        [window setTitle:@"Xputty macOS Window"];

        if (x == 0 && y == 0) {
            [window center];
        }

        [window makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];
        w->widget = (__bridge Window)window;

        NSLog(@"[CREATE] Main window frame: %@", NSStringFromRect([window frame]));
    }
    else if (win == (Window)kCGNullWindowID) {
        // Popup menu
        NSLog(@"[POPUP] Creating popup menu");
        NSLog(@"[POPUP] Input: x=%d y=%d w=%d h=%d", x, y, width, height);
        
        NSRect popupRect = NSMakeRect(x, y, width, height);
        NSLog(@"[POPUP] Final popup rect: %@", NSStringFromRect(popupRect));

        NSWindow *popup = [[NSWindow alloc] initWithContentRect:popupRect
                                                      styleMask:NSWindowStyleMaskBorderless
                                                        backing:NSBackingStoreBuffered
                                                          defer:NO];
        [popup setOpaque:NO];
        [popup setBackgroundColor:[NSColor clearColor]];
        [popup setLevel:NSFloatingWindowLevel];
        [popup setContentSize:NSMakeSize(width, height)];

        XWidgetView *view = [[XWidgetView alloc] initWithWidget:w frame:NSMakeRect(0, 0, width, 100)];
        [popup setContentView:view];

        w->widget = (__bridge Window)popup;

        NSLog(@"[POPUP] NSWindow created: %@", popup);
    }
    else if (win) {
        // Embedded widget inside another view
        NSLog(@"[CREATE] Embedded widget into parent view");
        NSView *parentView = (__bridge NSView *)win;
        NSRect rect = NSMakeRect(x, y, width, height);
        XWidgetView *view = [[XWidgetView alloc] initWithWidget:w frame:rect];
        [parentView addSubview:view];
        w->widget = (__bridge Window)view;
        NSLog(@"[CREATE] Embedded view frame: %@", NSStringFromRect(rect));
    }

    // Create Cairo surface
    w->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
    w->cr = cairo_create(w->surface);

    os_set_window_min_size(w, width / 2, height / 2, width, height);
}

void os_create_widget_window_and_surface(Widget_t* w, Xputty* app, Widget_t* parent,
                                         int x, int y, int width, int height) {
    if (!w || !parent || !parent->widget || width <= 1 || height <= 1) return;

    childlist_add_child(app->childlist, w);

    NSView *parentView = nil;
    id pobj = (__bridge id)parent->widget;
    if ([pobj isKindOfClass:[NSWindow class]]) {
        parentView = [(NSWindow*)pobj contentView];
    } else if ([pobj isKindOfClass:[NSView class]]) {
        parentView = (NSView*)pobj;
    } else {
        return;
    }

    NSRect frame = NSMakeRect(x, y, width, height);
    if (NSIsEmptyRect(frame)) return;

    // Create a custom NSView for the widget
    XWidgetView *view = [[XWidgetView alloc] initWithWidget:w frame:frame];
    if (!view) return;

    // Add the new view to its parent
    [parentView addSubview:view];
    w->widget = (__bridge Window)view;

    // Create Cairo surface and context for drawing
    w->surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
    w->cr = cairo_create(w->surface);
}

void os_set_title(Widget_t* w, const char* title) {
    if (!w || !w->widget) return;
    id obj = (__bridge id)w->widget;
    if ([obj isKindOfClass:[NSWindow class]]) {
        [(NSWindow*)obj setTitle:[NSString stringWithUTF8String:title]];
    }
}

void os_widget_show(Widget_t* w) {
    if (!w || !w->widget) return;
    id obj = (__bridge id)w->widget;

    if ([obj isKindOfClass:[NSWindow class]]) {
        if ([(NSWindow*)obj frame].size.width > 1 && [(NSWindow*)obj frame].size.height > 1) {
            [(NSWindow*)obj orderFront:nil];
        }
    } else if ([obj isKindOfClass:[NSView class]]) {
        if ([(NSView*)obj frame].size.width > 1 && [(NSView*)obj frame].size.height > 1) {
            [(NSView*)obj setHidden:NO];
        }
    }
}

void os_widget_hide(Widget_t* w) {
    if (!w || !w->widget) return;

    id obj = (__bridge id)w->widget;
    if ([obj isKindOfClass:[NSWindow class]]) {
        [(NSWindow*)obj orderOut:nil];
    } else if ([obj isKindOfClass:[NSView class]]) {
        [(NSView*)obj setHidden:YES];
    }

    // behave like on Linux: mark the widget as hidden
    w->flags |= HIDE_ON_DELETE;
}


void os_expose_widget(Widget_t* w) {
    if (!w || !w->widget || !w->surface || !w->cr) return;
    if (w->state == 4) return; // WIDGET DESTROYED/DEACTIVATED

    transparent_draw(w, NULL);

    id obj = (__bridge id)w->widget;
    if ([obj isKindOfClass:[NSWindow class]]) {
        [[(NSWindow*)obj contentView] setNeedsDisplay:YES];
    } else if ([obj isKindOfClass:[NSView class]]) {
        [(NSView*)obj setNeedsDisplay:YES];
    }
}





void os_send_configure_event(Widget_t* w, int x, int y, int width, int height) {
   //NOTHING
}

void os_send_button_press_event(Widget_t* w) {
   //NOTHING
}

void os_send_button_release_event(Widget_t* w) {
   //NOTHING
}

void os_adjustment_callback(void* w_, void* user_data) {
    Widget_t *w = (Widget_t *)w_;
    transparent_draw(w, user_data);
}

bool os_get_keyboard_input(Widget_t* w, XKeyEvent* key, char* buf, size_t bufsize) {
    if (bufsize < 2) return false;
    buf[0] = (char)key->keycode;
    buf[1] = 0;
    return true;
}

void os_free_pixmap(Widget_t* w, Pixmap pixmap) {}

void os_quit(Widget_t* w) {
    if (!w) return;

    // Safely close only this widget
    os_destroy_window(w);
}

void os_quit_widget(Widget_t* w) { os_destroy_window(w); }

Atom os_register_widget_destroy(Widget_t* wid) { return 0; }
Atom os_register_wm_delete_window(Widget_t* wid) { return 0; }

void os_widget_event_loop(void* w_, void* event, Xputty* main, void* user_data) {
   //Nothing
}

void os_run_embedded(Xputty* main) {
    NSEvent *event;
    while ((event = [NSApp nextEventMatchingMask:NSEventMaskAny
                                        untilDate:[NSDate distantPast]
                                           inMode:NSDefaultRunLoopMode
                                          dequeue:YES])) {
        [NSApp sendEvent:event];
    }
}

void os_send_systray_message(Widget_t* w) {
    //Nothing
}
void os_show_tooltip(Widget_t* wid, Widget_t* w) {
    //Nothing
}

void os_main_run(Xputty* main) { 
    [NSApp run]; 
}

} // extern "C"

#endif // __APPLE__